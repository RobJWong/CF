//
//  ImageNotesCell.swift
//  Travels
//
//  Created by Robert Wong on 1/17/18.
//  Copyright © 2018 Robert Wong. All rights reserved.
//

import UIKit

class ImageNotesCell: UITableViewCell {
    
    @IBOutlet weak var storedImage: UIImageView!
    @IBOutlet weak var notes: UITextView!
}
