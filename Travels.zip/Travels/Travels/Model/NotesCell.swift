//
//  NotesCell.swift
//  Travels
//
//  Created by Robert Wong on 2/7/18.
//  Copyright © 2018 Robert Wong. All rights reserved.
//

import UIKit

class NotesCell: UITableViewCell {
    
    @IBOutlet weak var notes: UITextView!
}
