//
//  UserInfo.swift
//  CheapMessengerAppV1
//
//  Created by Robert Wong on 10/17/17.
//  Copyright © 2017 Robert Wong. All rights reserved.
//

import UIKit

class UserInfo: NSObject {
    var name: String?
    var email: String?
}
