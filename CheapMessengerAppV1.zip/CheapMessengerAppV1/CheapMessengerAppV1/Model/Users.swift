//
//  Users.swift
//  CheapMessengerAppV1
//
//  Created by Robert Wong on 10/20/17.
//  Copyright © 2017 Robert Wong. All rights reserved.
//

import UIKit

class Users: NSObject {
    
    var name: String?
    var email: String?
    var userIdKey: String?
}

