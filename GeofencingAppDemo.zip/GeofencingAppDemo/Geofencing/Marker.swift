

//
//  Marker.swift
//  Geofencing
//
//  Created by Robert Wong on 9/22/17.
//  Copyright © 2017 CareerFoundry. All rights reserved.
//

import Foundation
